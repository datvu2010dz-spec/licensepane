# Build IPA with GitHub Actions

1. Upload the project ZIP to your GitHub repository.
2. Put this workflow at `.github/workflows/main.yml` (this package already includes it).
3. In **Settings → Secrets and variables → Actions**, add:
   - `P12_BASE64`
   - `P12_PASSWORD`
   - `PROVISION_PROFILE_BASE64`
4. Open **Actions → Build iOS IPA → Run workflow**.
5. When green, open the run and download the **LicensePanelApp-IPA** artifact.

Never commit the `.p12`, provisioning profile, or password to the repository.
