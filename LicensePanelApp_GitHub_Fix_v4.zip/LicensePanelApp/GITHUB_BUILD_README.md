# GitHub Actions build

Required repository secrets:
- `P12_BASE64` — Base64 of your signing `.p12`.
- `P12_PASSWORD` — password of the `.p12`.
- `PROVISION_PROFILE_BASE64` — Base64 of your `.mobileprovision`.

Do not commit `.p12`, private keys, provisioning profiles, or passwords to the repository.

Run: GitHub → Actions → Build iOS IPA → Run workflow → choose `ad-hoc` or `development`.
The IPA will appear under Artifacts as `LicensePanelApp-IPA`.
