# License Panel iOS

Standalone SwiftUI license-manager app inspired by the supplied screenshots.

## Included
- Dark authentication screen
- License validation using the supplied key
- Expiry / days remaining display
- Home, Log, and Settings tabs
- Screenshot/recording and performance UI
- No integration with games, game memory, game processes, or anti-cheat bypasses

## License key
The app currently contains the supplied key:

`FreeFireMax-DS-593420`

You can change it in `LicensePanelApp/ContentView.swift` in `LicenseStore.validKey`.

## Build an IPA
1. Open `LicensePanelApp.xcodeproj` in Xcode on a Mac.
2. Select your Apple Developer team under Signing & Capabilities.
3. Change the bundle identifier from `com.example.licensepanel` to one you own.
4. Select an iPhone target.
5. Product -> Archive.
6. In Organizer, choose Distribute App and export/sign the IPA according to your Apple account.

The project targets iOS 17+.


## Version 2 settings
The Settings toggles now work as normal SwiftUI controls and persist locally using `@AppStorage`, so their ON/OFF values survive app restarts. The refresh-rate slider also persists its value.

These controls are standalone app settings; they do not alter any game or game process.
