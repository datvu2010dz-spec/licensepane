import SwiftUI

struct ContentView: View {
    @StateObject private var license = LicenseStore()

    var body: some View {
        Group {
            if license.isAuthenticated {
                MainTabView()
                    .environmentObject(license)
            } else {
                AuthenticationView()
                    .environmentObject(license)
            }
        }
    }
}

final class LicenseStore: ObservableObject {
    @Published var isAuthenticated = false
    @Published var isValidating = false
    @Published var message = "Enter a valid key."

    // Standalone license token. It is not connected to any game or game process.
    private let validKey = "FreeFireMax-DS-593420"
    let expiry = Calendar.current.date(from: DateComponents(year: 2026, month: 9, day: 11))!

    func validate(_ key: String) {
        isValidating = true
        message = "Validating license and protected resources..."

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            if key.trimmingCharacters(in: .whitespacesAndNewlines) == self.validKey {
                self.isAuthenticated = true
                self.message = "License validated."
            } else {
                self.message = "Enter a valid key."
            }
            self.isValidating = false
        }
    }

    var daysRemaining: Int {
        max(0, Calendar.current.dateComponents([.day], from: Date(), to: expiry).day ?? 0)
    }
}

struct AuthenticationView: View {
    @EnvironmentObject var license: LicenseStore
    @State private var key = "FreeFireMax-DS-593420"

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 24) {
                Spacer()

                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 58))
                    .foregroundStyle(.cyan)

                Text("Authentication Required")
                    .font(.system(size: 30, weight: .regular))
                    .foregroundStyle(.white)

                Text(license.message)
                    .font(.system(size: 17))
                    .foregroundStyle(.gray)

                TextField("License key", text: $key)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(16)
                    .background(Color.white.opacity(0.035))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.white.opacity(0.18), lineWidth: 1)
                    )
                    .foregroundStyle(.white)
                    .padding(.horizontal, 38)

                Button {
                    license.validate(key)
                } label: {
                    HStack {
                        Spacer()
                        Text("Log In")
                            .font(.system(size: 20, weight: .semibold))
                        Spacer()
                    }
                    .padding(.vertical, 18)
                    .background(Color.cyan.opacity(0.65))
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .foregroundStyle(.white.opacity(0.8))
                }
                .padding(.horizontal, 38)
                .disabled(license.isValidating)

                if license.isValidating {
                    ProgressView()
                        .tint(.gray)
                }

                Spacer()
                Text("Standalone license manager")
                    .font(.footnote)
                    .foregroundStyle(.gray)
                    .padding(.bottom, 30)
            }
        }
    }
}

struct MainTabView: View {
    var body: some View {
        TabView {
            GameView()
                .tabItem {
                    Label("Home", systemImage: "gamecontroller.fill")
                }

            LogView()
                .tabItem {
                    Label("Log", systemImage: "terminal")
                }

            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gearshape")
                }
        }
        .tint(.cyan)
    }
}

struct GameView: View {
    @EnvironmentObject var license: LicenseStore

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("STATUS")
                        .font(.caption)
                        .foregroundStyle(.gray)
                        .padding(.horizontal, 40)

                    Panel {
                        HStack(spacing: 16) {
                            Image(systemName: "checkmark.seal.fill")
                                .font(.title2)
                                .foregroundStyle(.green)

                            VStack(alignment: .leading, spacing: 4) {
                                Text("Active")
                                    .font(.title3.bold())
                                Text("License session is active.")
                                    .foregroundStyle(.gray)
                            }
                            Spacer()
                        }
                    }

                    Text("LICENSE")
                        .font(.caption)
                        .foregroundStyle(.gray)
                        .padding(.horizontal, 40)
                        .padding(.top, 8)

                    Panel {
                        InfoRow(title: "Status", value: "Valid")
                        Divider()
                        InfoRow(title: "Expires", value: dateString(license.expiry))
                        Divider()
                        InfoRow(title: "Days remaining", value: "\(license.daysRemaining)")
                    }
                }
                .padding(.top, 24)
            }
            .background(Color.black)
            .navigationTitle("Home")
        }
    }
}

struct LogView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    Text("@LicensePanel")
                        .font(.system(.headline, design: .monospaced))
                    Text("Standalone License Manager | Version: 1.0 (1)")
                        .font(.system(.body, design: .monospaced))
                    Text("License validated successfully.")
                        .font(.system(.body, design: .monospaced))
                        .foregroundStyle(.green)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(22)
                .background(Color(red: 0.055, green: 0.06, blue: 0.09))
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .padding(20)
            }
            .background(Color.black)
            .navigationTitle("Log")
        }
    }
}


struct AppSettings {
    static let launchOnOpen = "settings.launchOnOpen"
    static let backgroundValidation = "settings.backgroundValidation"
    static let hideInRecording = "settings.hideInRecording"
    static let compactMode = "settings.compactMode"
    static let showStatus = "settings.showStatus"
    static let refreshRate = "settings.refreshRate"
}

struct SettingsView: View {
    @AppStorage(AppSettings.launchOnOpen) private var launchOnOpen = true
    @AppStorage(AppSettings.backgroundValidation) private var backgroundValidation = true
    @AppStorage(AppSettings.hideInRecording) private var hideInRecording = false
    @AppStorage(AppSettings.compactMode) private var compactMode = false
    @AppStorage(AppSettings.showStatus) private var showStatus = false
    @AppStorage(AppSettings.refreshRate) private var refreshRate = 45.0

    var body: some View {
        NavigationStack {
            Form {
                Section("QUICK ACTIONS") {
                    Button(role: .destructive) {
                        // UI-only cleanup action.
                    } label: {
                        Label("Clean Up", systemImage: "xmark.circle.fill")
                    }

                    Button {
                        // UI-only contact action.
                    } label: {
                        Label("Contact", systemImage: "paperplane.fill")
                    }
                }

                Section("LAUNCH OPTIONS") {
                    Toggle("Launch on Open", isOn: $launchOnOpen)
                    Toggle("Background Validation", isOn: $backgroundValidation)
                }

                Section("DISPLAY") {
                    Toggle("Hide in Screenshot/Recording", isOn: $hideInRecording)
                    Toggle("Compact Mode", isOn: $compactMode)
                    Toggle("Show Status", isOn: $showStatus)
                }

                Section("PERFORMANCE") {
                    VStack(alignment: .leading) {
                        Text("Refresh rate")
                        Slider(value: $refreshRate, in: 15...60, step: 1)
                        Text("\(Int(refreshRate)) Hz max")
                            .foregroundStyle(.secondary)
                    }
                }

                Section("CURRENT CONFIGURATION") {
                    LabeledContent("Launch", value: launchOnOpen ? "ON" : "OFF")
                    LabeledContent("Background validation", value: backgroundValidation ? "ON" : "OFF")
                    LabeledContent("Hide in recording", value: hideInRecording ? "ON" : "OFF")
                    LabeledContent("Compact mode", value: compactMode ? "ON" : "OFF")
                    LabeledContent("Show status", value: showStatus ? "ON" : "OFF")
                    LabeledContent("Refresh", value: "\(Int(refreshRate)) Hz")
                }

                Section("ABOUT") {
                    LabeledContent("Version", value: "1.0")
                    LabeledContent("Build", value: "2")
                    LabeledContent("Bundle", value: "com.example.licensepanel")
                    LabeledContent("Supported", value: "iOS 17+")
                }

                Section {
                    Text("Settings are saved locally with AppStorage and restored when the app is reopened. This app is standalone and does not connect to or modify games, game processes, or game memory.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.black)
            .navigationTitle("Settings")
        }
    }
}

struct Panel<Content: View>: View {
    @ViewBuilder let content: Content
    var body: some View {
        content
            .padding(18)
            .background(Color.white.opacity(0.075))
            .clipShape(RoundedRectangle(cornerRadius: 18))
            .padding(.horizontal, 20)
    }
}

struct InfoRow: View {
    let title: String
    let value: String

    var body: some View {
        HStack {
            Text(title)
            Spacer()
            Text(value).foregroundStyle(.gray)
        }
    }
}

func dateString(_ date: Date) -> String {
    let f = DateFormatter()
    f.dateFormat = "yyyy-MM-dd"
    return f.string(from: date)
}
