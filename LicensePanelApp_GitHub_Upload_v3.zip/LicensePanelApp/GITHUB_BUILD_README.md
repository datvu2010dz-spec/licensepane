# LicensePanelApp — GitHub Actions build

Đây là bản project đã chuẩn bị để GitHub Actions build IPA trên macOS runner.

## Quan trọng

- Không upload file `.p12`, mật khẩu `.p12`, hoặc `.mobileprovision` vào repository.
- Hãy lưu chúng trong **GitHub Secrets**.
- Workflow này chỉ build ứng dụng License Panel độc lập; không có tích hợp/cheat vào game.

## 3 GitHub Secrets cần tạo

Vào repository → **Settings → Secrets and variables → Actions → New repository secret**:

1. `P12_BASE64`
   - Nội dung là file `.p12` đã được Base64.
2. `P12_PASSWORD`
   - Mật khẩu của file `.p12`.
3. `PROVISION_PROFILE_BASE64`
   - Nội dung file `.mobileprovision` đã được Base64.

### Base64 trên iPhone

Có thể dùng app Shortcuts:
1. Get File → chọn file `.p12`.
2. Base64 Encode.
3. Copy to Clipboard.
4. Dán vào GitHub Secret `P12_BASE64`.

Làm tương tự với `.mobileprovision`.

**Không gửi mật khẩu `.p12` cho người khác.**

## Chạy build

Sau khi tạo 3 Secrets:
- Mở tab **Actions**.
- Chọn **Build iOS IPA**.
- Bấm **Run workflow** → branch `main` → **Run workflow**.
- Khi xanh (Success), mở run đó.
- Kéo xuống **Artifacts**.
- Chọn `LicensePanelApp-IPA` để lấy file IPA.

Nếu provisioning profile không khớp với certificate/team/app ID, phần Archive/Export sẽ báo lỗi trong log. 
